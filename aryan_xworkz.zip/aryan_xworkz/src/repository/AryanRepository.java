package repository;

import dto.AryanDTO;

public interface AryanRepository {
    public void save(AryanDTO aryanDTO);
}
