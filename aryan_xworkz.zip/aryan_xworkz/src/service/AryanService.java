package service;

import dto.AryanDTO;

public interface AryanService {
    public String validateandSave(AryanDTO aryanDTO);

}
